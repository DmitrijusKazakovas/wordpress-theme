<form action="<?php echo home_url(); ?>" method="get">
    <input type="search" name="search" placeholder="Search Here" value="<?php echo get_search_query(); ?>">
    <input type="submit" id="search-btn" value="">
</form>